"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { MessageCircle, Sparkles, UserX, Lock, Shield, Heart, ArrowRight, Globe } from "lucide-react";
import { TR } from "@/lib/questions";

export default function LandingPage() {
  const [lang, setLang] = useState<"ar" | "en">("ar");
  const [loading, setLoading] = useState(false);
  const t = TR[lang];
  const dir = lang === "ar" ? "rtl" : "ltr";
  const router = useRouter();

  async function startSession() {
    setLoading(true);
    const res = await fetch("/api/session/create", { method: "POST" });
    const data = await res.json();
    setLoading(false);
    if (data.code) router.push(`/s/${data.code}?lang=${lang}`);
  }

  return (
    <div dir={dir} className="min-h-screen font-body" style={{ color: "#2E2438" }}>
      <button
        onClick={() => setLang(lang === "en" ? "ar" : "en")}
        className="fixed top-4 end-4 z-40 flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-semibold bg-white/90 border shadow-sm"
        style={{ borderColor: "#EDE3E0", color: "#3D5A6C" }}
      >
        <Globe size={13} /> {t.langToggle}
      </button>

      <div className="max-w-xl mx-auto px-6 pt-16 pb-24">
        <div className="flex items-center gap-2 mb-14 justify-center">
          <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: "#3D5A6C" }}>
            <MessageCircle className="text-white" size={18} />
          </div>
          <span className="font-display text-xl tracking-tight">{t.logo}</span>
        </div>

        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-xs font-semibold mb-6"
            style={{ background: "#F6E4CB", color: "#8A5A1E" }}>
            <Sparkles size={13} /> {t.heroBadge}
          </div>
          <h1 className="font-display text-[2.2rem] sm:text-[2.7rem] leading-[1.15] tracking-tight mb-5">
            {t.heroTitle1}<br /><em className="not-italic" style={{ color: "#E98973" }}>{t.heroTitleEm}</em> {t.heroTitle2}
          </h1>
          <p className="text-[17px] leading-relaxed max-w-md mx-auto" style={{ color: "#5B5065" }}>
            {t.heroSub}
          </p>
        </div>

        <div className="flex justify-center mb-14">
          <button
            onClick={startSession}
            disabled={loading}
            className="font-body inline-flex items-center justify-center gap-2 rounded-2xl px-8 py-4 text-base font-semibold text-white shadow-[0_8px_24px_-8px_rgba(61,90,108,0.5)] hover:-translate-y-0.5 transition-all disabled:opacity-50"
            style={{ background: "#3D5A6C" }}
          >
            {loading ? "..." : t.startSession} <ArrowRight size={17} className="rtl:rotate-180" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {[[UserX, t.noAccount], [Lock, t.noContact], [Shield, t.anonymous], [Heart, t.private]].map(([Icon, label]: any, i) => (
            <div key={i} className="flex items-center gap-2.5 rounded-2xl px-4 py-3.5 bg-white/70 border" style={{ borderColor: "#EDE3E0" }}>
              <Icon size={17} style={{ color: "#3D5A6C" }} />
              <span className="text-[13.5px] font-medium">{label}</span>
            </div>
          ))}
        </div>

        <p className="text-center text-xs mt-10" style={{ color: "#9A8FA0" }}>{t.footerPrivacy}</p>
      </div>
    </div>
  );
}
