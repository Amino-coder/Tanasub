"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import {
  Heart, Lock, ArrowRight, ArrowLeft, Check, MessageCircle, Sparkles,
  Copy, Share2, Globe,
} from "lucide-react";
import { TR, QUESTIONS } from "@/lib/questions";
import { buildResults } from "@/lib/results";

type Answers = Record<string, any>;

function useLocalKey(code: string) {
  return `together_pid_${code}`;
}

export default function SessionPage({ params }: { params: { code: string } }) {
  const code = params.code;
  const search = useSearchParams();
  const [lang, setLang] = useState<"ar" | "en">((search.get("lang") as "ar" | "en") || "ar");
  const t = TR[lang];
  const dir = lang === "ar" ? "rtl" : "ltr";
  const pidKey = useLocalKey(code);

  const [stage, setStage] = useState<"loading" | "nickname" | "quiz" | "waiting" | "results" | "full" | "notfound">("loading");
  const [role, setRole] = useState<"A" | "B" | null>(null);
  const [participantId, setParticipantId] = useState<string | null>(null);
  const [nickname, setNickname] = useState("");
  const [answers, setAnswers] = useState<Answers>({});
  const [qIndex, setQIndex] = useState(0);
  const [confetti, setConfetti] = useState(false);
  const [results, setResults] = useState<any>(null);
  const [otherNickname, setOtherNickname] = useState("");
  const pollRef = useRef<any>(null);

  // Resume or begin joining
  useEffect(() => {
    const savedPid = typeof window !== "undefined" ? localStorage.getItem(pidKey) : null;
    if (savedPid) {
      setParticipantId(savedPid);
      checkStatus(savedPid);
    } else {
      setStage("nickname");
    }
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function checkStatus(pid: string) {
    const res = await fetch(`/api/session/${code}`);
    if (!res.ok) { setStage("notfound"); return; }
    const data = await res.json();
    const a = data.participants.A, b = data.participants.B;
    // Role isn't returned by GET (by design), so it's tracked in localStorage instead
    const savedRole = localStorage.getItem(pidKey + "_role") as "A" | "B" | null;
    setRole(savedRole);
    const myRecord = savedRole === "A" ? a : b;
    const otherRecord = savedRole === "A" ? b : a;
    if (myRecord?.completed && data.bothDone) {
      setOtherNickname(otherRecord?.nickname || "");
      const raw = await fetch(`/api/session/${code}`).then(r => r.json());
      const nA = raw.participants.A.nickname || t.youAre;
      const nB = raw.participants.B.nickname || t.personB;
      const res2 = buildResults(raw.participants.A.answers, raw.participants.B.answers, nA, nB, lang);
      setResults({ ...res2, nameA: nA, nameB: nB });
      setStage("results");
      setConfetti(true);
      setTimeout(() => setConfetti(false), 2200);
    } else if (myRecord?.completed) {
      setOtherNickname(otherRecord?.nickname || "");
      setStage("waiting");
      startPolling(pid);
    } else {
      setStage("quiz");
    }
  }

  function startPolling(pid: string) {
    if (pollRef.current) clearInterval(pollRef.current);
    pollRef.current = setInterval(() => checkStatus(pid), 3000);
  }

  async function joinSession() {
    if (!nickname.trim()) return;
    const res = await fetch("/api/participant", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code, nickname: nickname.trim() }),
    });
    if (!res.ok) { setStage("full"); return; }
    const data = await res.json();
    localStorage.setItem(pidKey, data.participantId);
    localStorage.setItem(pidKey + "_role", data.role);
    setParticipantId(data.participantId);
    setRole(data.role);
    setStage("quiz");
  }

  async function answerAndAdvance(val: any) {
    const q = QUESTIONS[qIndex];
    const next = { ...answers, [q.id]: val };
    setAnswers(next);
    setTimeout(async () => {
      if (qIndex < QUESTIONS.length - 1) {
        setQIndex(i => i + 1);
      } else {
        await fetch("/api/answers", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ participantId, answers: next, completed: true }),
        });
        setStage("waiting");
        if (participantId) startPolling(participantId);
        checkStatus(participantId!);
      }
    }, 200);
  }

  const q = QUESTIONS[qIndex];

  return (
    <div dir={dir} className="min-h-screen w-full font-body" style={{ background: "#FAF6F2", color: "#2E2438" }}>
      {confetti && <Confetti />}
      <button
        onClick={() => setLang(lang === "en" ? "ar" : "en")}
        className="fixed top-4 end-4 z-40 flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-semibold bg-white/90 border shadow-sm"
        style={{ borderColor: "#EDE3E0", color: "#3D5A6C" }}
      >
        <Globe size={13} /> {t.langToggle}
      </button>

      {stage === "loading" && <Centered>...</Centered>}
      {stage === "notfound" && <Centered>Session not found.</Centered>}
      {stage === "full" && <Centered>This session already has two participants.</Centered>}

      {stage === "nickname" && (
        <div className="max-w-xl mx-auto px-6 pt-24 pb-24">
          <h2 className="font-display text-3xl mb-3">{t.whatCallYou}</h2>
          <p className="text-[15px] mb-8" style={{ color: "#5B5065" }}>{t.nicknameSub}</p>
          <input
            value={nickname} onChange={e => setNickname(e.target.value)}
            placeholder={t.nicknamePlaceholder} autoFocus
            className="w-full rounded-2xl px-5 py-4 text-lg mb-8 border-2 outline-none focus:border-[#3D5A6C]"
            style={{ borderColor: "#EDE3E0" }}
          />
          <PrimaryButton onClick={joinSession} disabled={!nickname.trim()}>
            {t.begin} <ArrowRight size={16} className="rtl:rotate-180" />
          </PrimaryButton>
        </div>
      )}

      {stage === "quiz" && q && (
        <div className="max-w-xl mx-auto px-6 pt-8 pb-24 min-h-screen flex flex-col">
          <div className="flex items-center justify-between mb-3">
            <button onClick={() => setQIndex(i => Math.max(0, i - 1))} disabled={qIndex === 0} className="disabled:opacity-0" style={{ color: "#9A8FA0" }}>
              <ArrowLeft size={18} className="rtl:rotate-180" />
            </button>
            <span className="text-xs font-semibold" style={{ color: "#9A8FA0" }}>{qIndex + 1} / {QUESTIONS.length}</span>
          </div>
          <div className="w-full h-1.5 rounded-full bg-[#EDE3E0] overflow-hidden">
            <div className="h-full rounded-full transition-all duration-500" style={{ width: `${(qIndex / QUESTIONS.length) * 100}%`, background: "linear-gradient(90deg,#E98973,#3D5A6C)" }} />
          </div>
          <div className="flex-1 flex flex-col justify-center mt-10">
            <p className="text-xs font-semibold uppercase tracking-wide mb-3" style={{ color: "#E98973" }}>{t.sectionLabels[q.section]}</p>
            <h2 key={q.id} className="font-display text-2xl leading-snug mb-8" style={{ animation: "fadein .35s ease" }}>
              {lang === "ar" ? q.prompt_ar : q.prompt}
            </h2>
            {q.type === "text" ? (
              <TextAnswer t={t} onAnswer={answerAndAdvance} isLast={qIndex === QUESTIONS.length - 1} />
            ) : (
              <div className="space-y-3">
                {q.options!.map((opt: any, i: number) => (
                  <button key={i} onClick={() => answerAndAdvance(i)}
                    className="w-full text-start rounded-2xl px-5 py-4 text-[15px] font-medium border-2 transition-all hover:-translate-y-0.5"
                    style={{ borderColor: answers[q.id] === i ? "#3D5A6C" : "#EDE3E0", background: answers[q.id] === i ? "#3D5A6C" : "white", color: answers[q.id] === i ? "white" : "#2E2438" }}>
                    {lang === "ar" ? opt.label_ar : opt.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {stage === "waiting" && (
        <div className="max-w-xl mx-auto px-6 pt-24 pb-24 text-center">
          <div className="w-16 h-16 rounded-full mx-auto mb-8 flex items-center justify-center" style={{ background: "#F6E4CB" }}>
            <Heart size={26} style={{ color: "#E98973" }} />
          </div>
          <h2 className="font-display text-3xl mb-3">{t.doneTitle}</h2>
          <p className="text-[15px] mb-4 whitespace-pre-line" style={{ color: "#5B5065" }}>
            {lang === "ar" ? "بانتظار الطرف الثاني لإنهاء الأسئلة. سيتحدث هذا تلقائيًا." : "Waiting for the other person to finish. This will update automatically."}
          </p>
          <div className="rounded-xl px-4 py-3 inline-flex items-center gap-2 text-xs font-semibold" style={{ background: "#EDE9F2", color: "#3D5A6C" }}>
            <Lock size={13} /> {t.footerNote}
          </div>
        </div>
      )}

      {stage === "results" && results && (
        <ResultsView t={t} nameA={results.nameA} nameB={results.nameB} results={results} />
      )}
    </div>
  );
}

function Centered({ children }: any) {
  return <div className="min-h-screen flex items-center justify-center text-sm" style={{ color: "#5B5065" }}>{children}</div>;
}

function PrimaryButton({ children, onClick, disabled }: any) {
  return (
    <button onClick={onClick} disabled={disabled}
      className="font-body w-full inline-flex items-center justify-center gap-2 rounded-2xl px-6 py-3.5 text-[15px] font-semibold text-white transition-all disabled:opacity-40 hover:-translate-y-0.5 shadow-[0_8px_24px_-8px_rgba(61,90,108,0.5)]"
      style={{ background: "#3D5A6C" }}>
      {children}
    </button>
  );
}

function TextAnswer({ t, onAnswer, isLast }: any) {
  const [text, setText] = useState("");
  return (
    <div>
      <textarea value={text} onChange={e => setText(e.target.value)} rows={4} autoFocus
        className="w-full rounded-2xl px-5 py-4 text-[15px] border-2 outline-none focus:border-[#3D5A6C] resize-none mb-5"
        style={{ borderColor: "#EDE3E0" }} placeholder={t.textPlaceholder} />
      <PrimaryButton onClick={() => onAnswer(text.trim() || "—")}>
        {isLast ? t.finish : t.next} <ArrowRight size={16} className="rtl:rotate-180" />
      </PrimaryButton>
    </div>
  );
}

function TraitPill({ label }: { label: string }) {
  return <span className="inline-block rounded-full px-3.5 py-1.5 text-[13px] font-semibold m-1" style={{ background: "#EDE9F2", color: "#3D5A6C" }}>{label}</span>;
}

function Section({ title, icon: Icon, tint, iconColor, children }: any) {
  return (
    <div className="mb-10">
      <div className="flex items-center gap-2.5 mb-4">
        <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: tint }}>
          <Icon size={15} style={{ color: iconColor }} />
        </div>
        <h3 className="font-display text-xl">{title}</h3>
      </div>
      {children}
    </div>
  );
}

function ResultsView({ t, nameA, nameB, results }: any) {
  const { traitsA, traitsB, similarities, topics, starters, greenFlags } = results;
  return (
    <div className="max-w-2xl mx-auto px-6 pt-14 pb-28">
      <div className="text-center mb-12">
        <p className="text-xs font-semibold uppercase tracking-wide mb-2" style={{ color: "#9A8FA0" }}>{t.reportUnlocked}</p>
        <h1 className="font-display text-3xl mb-2">{nameA} &amp; {nameB}</h1>
        <p className="text-[15px]" style={{ color: "#5B5065" }}>{t.reportSub}</p>
      </div>

      <div className="grid sm:grid-cols-2 gap-4 mb-10">
        {[[nameA, traitsA], [nameB, traitsB]].map(([name, traits]: any, i: number) => (
          <div key={i} className="rounded-3xl p-5 bg-white border" style={{ borderColor: "#EDE3E0" }}>
            <p className="font-display text-lg mb-3">{name}</p>
            <div className="flex flex-wrap -m-1">{traits.map((tr: string, j: number) => <TraitPill key={j} label={tr} />)}</div>
          </div>
        ))}
      </div>

      <Section title={t.inCommon} icon={Heart} tint="#F6E4CB" iconColor="#8A5A1E">
        <ul className="space-y-2.5">{similarities.map((s: string, i: number) => <li key={i} className="text-[14.5px]" style={{ color: "#4A4152" }}>· {s}</li>)}</ul>
      </Section>

      <Section title={t.topicsTitle} icon={MessageCircle} tint="#EDE9F2" iconColor="#3D5A6C">
        <div className="space-y-3">
          {topics.map((tp: any, i: number) => (
            <div key={i} className="rounded-2xl p-4 bg-white border" style={{ borderColor: "#EDE3E0" }}>
              <p className="text-sm font-semibold mb-2">{tp.title}</p>
              <div className="flex gap-2 flex-wrap text-[13px]">
                <span className="rounded-full px-3 py-1" style={{ background: "#FAF6F2" }}>{nameA}: {tp.a}</span>
                <span className="rounded-full px-3 py-1" style={{ background: "#FAF6F2" }}>{nameB}: {tp.b}</span>
              </div>
            </div>
          ))}
          {!topics.length && <p className="text-sm" style={{ color: "#9A8FA0" }}>{t.topicsEmpty}</p>}
        </div>
      </Section>

      <Section title={t.startersTitle} icon={Sparkles} tint="#FBE7E3" iconColor="#C2624C">
        <div className="space-y-3">{starters.map((s: string, i: number) => <div key={i} className="rounded-2xl px-4 py-3.5" style={{ background: "#FBE7E3" }}><p className="text-[14.5px]" style={{ color: "#4A2E27" }}>{s}</p></div>)}</div>
      </Section>

      <Section title={t.greenFlagsTitle} icon={Check} tint="#E4EFE6" iconColor="#3F7A55">
        <ul className="space-y-2.5">{greenFlags.map((g: string, i: number) => <li key={i} className="text-[14.5px]" style={{ color: "#4A4152" }}>· {g}</li>)}</ul>
      </Section>

      <p className="text-center text-xs mt-14" style={{ color: "#C9BFC9" }}>{t.footerNote}</p>
    </div>
  );
}

function Confetti() {
  const pieces = useMemo(() => Array.from({ length: 40 }, (_, i) => ({
    id: i, left: Math.random() * 100, delay: Math.random() * 0.6,
    color: ["#E98973", "#3D5A6C", "#F6C453", "#7BA98A"][i % 4], rotate: Math.random() * 360,
  })), []);
  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
      {pieces.map(p => (
        <div key={p.id} style={{ position: "absolute", left: `${p.left}%`, top: "-5%", width: 8, height: 8, background: p.color, animation: `fall 1.8s ease-in ${p.delay}s forwards`, transform: `rotate(${p.rotate}deg)`, borderRadius: 2 }} />
      ))}
    </div>
  );
}
